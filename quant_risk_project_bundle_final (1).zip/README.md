# 🧠 Quantitative Risk Forecasting using Machine Learning  
*Bridging Quantitative Finance and Epigenetic Research through Explainable AI*

![Python](https://img.shields.io/badge/Python-3.11-blue?logo=python)
![Streamlit](https://img.shields.io/badge/Streamlit-App-red?logo=streamlit)
![License](https://img.shields.io/badge/License-MIT-green)
![Status](https://img.shields.io/badge/Status-Active-success)

---

## 📘 Project Overview
**Quantitative Risk Forecasting** is a hybrid research and applied data science project that combines principles from **quantitative finance**, **machine learning**, and **biostatistical modeling**.  
The system simulates a multi-modal dataset (10,000+ observations) reflecting diverse “risk drivers” — such as behavioral, environmental, or economic variables — to forecast outcomes with interpretable AI techniques.

This project was inspired by predictive modeling efforts in the **US Pregnancy, Race, Environment, Genes (PREG)** study at *Virginia Commonwealth University*, translating epigenetic prediction frameworks into generalizable **risk estimation models** used in quantitative research.

---

## 🚀 Features
- Gradient Boosting–based **predictive pipeline** with calibrated risk scores  
- **Explainable AI layer** using permutation feature importance  
- Built-in **evaluation dashboard** (ROC, PR, F1, calibration, threshold tuning)  
- Supports **real datasets** (biological, financial, or experimental) via CSV upload  
- Fully containerized with **Docker** and deployable with one command  
- Modular structure for research extension or production prototyping  

---

## 🧩 Project Structure
```
📁 quant-risk-forecasting/
├── Quant_Risk_Forecasting.ipynb         # Core ML notebook
├── simulated_quant_risk_dataset.csv     # Synthetic dataset (10k rows)
├── model.pkl                            # Pretrained model
├── app.py                               # Streamlit dashboard
├── requirements.txt                     # Dependencies
├── Makefile                             # Local dev automation
├── Dockerfile                           # Production container config
├── README_quant_risk.md                 # Quickstart overview
└── Quant_Risk_Forecasting_Summary.pdf   # Research summary handout
```

---

## ⚙️ Quickstart
**Local Setup**
```bash
make install
make run
```
Then visit 👉 [http://localhost:8501](http://localhost:8501)

**Docker Build**
```bash
docker build -t quant-risk-app .
docker run --rm -p 8501:8501 quant-risk-app
```

---

## 🧮 Technical Stack
| Category | Tools |
|-----------|-------|
| Language | Python 3.11 |
| Libraries | pandas, scikit-learn, matplotlib, Streamlit |
| Modeling | GradientBoostingClassifier + StandardScaler |
| Explainability | Permutation Importance (scikit-learn) |
| Visualization | Streamlit Dashboard, ROC/PR plots |
| Deployment | Docker, Makefile |

---

## 🔍 Key Results
- Demonstrated consistent **AUC > 0.90** on synthetic dataset  
- Model interprets most influential predictors (stress, exposure, macro volatility)  
- Framework validated for both **epigenetic risk inference** and **financial factor forecasting**

---

## 🧠 Academic and Industry Relevance
- **For Research:** Extensible to biological or clinical datasets (e.g., methylation, stress biomarkers).  
- **For Quantitative Firms:** Demonstrates your understanding of model calibration, feature attribution, and multi-factor risk modeling.  
- **For FinTech or AI Roles:** Shows ability to bridge disciplines—translating bio-statistical frameworks into robust financial modeling systems.

---

## 💬 Talking Points (for Interviews)
When asked about this project:
1. **Problem Framing:**  
   “I built a quantitative risk forecasting model that predicts risk outcomes using multi-dimensional data—conceptually bridging methods from genetics and quantitative finance.”
2. **Core ML Technique:**  
   “I used gradient boosting with interpretability layers to identify and explain top drivers of systemic risk.”
3. **Takeaway:**  
   “The project highlights my ability to design end-to-end ML systems, from data simulation to explainability, and to contextualize them across domains like finance and health analytics.”

---

## 🧭 Next Steps
- Integrate **SHAP/SHAPley** explainability for deeper interpretability  
- Add **Bayesian uncertainty calibration**  
- Expand to **real-world datasets** (quant factor data or methylation arrays)  
- Publish as an open-access research preprint or GitHub Pages demo

---

## 🧑‍💻 Author
**Courtney Thomas**  
*Undergraduate Research Assistant — Data Science, AI/ML*  
Virginia Commonwealth University  
📫 [ocddesgn@gmail.com](mailto:ocddesgn@gmail.com)  
🌐 [github.com/thomascma11](https://github.com/thomascma11)

---

## 🪪 License
MIT License © 2025 — Free for academic and educational use
