
import streamlit as st
import pandas as pd
import numpy as np
import pickle
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.metrics import roc_auc_score, average_precision_score, brier_score_loss, roc_curve, precision_recall_curve
from sklearn.ensemble import GradientBoostingClassifier
import matplotlib.pyplot as plt
import os

st.set_page_config(page_title="Risk Forecasting Dashboard", layout="wide")
st.title("Quantitative Risk Forecasting • Explainable ML")
st.write("Auto-loads a pre-trained pipeline if 'model.pkl' is present; otherwise trains on the provided CSV.")

# Sidebar: data
st.sidebar.header("Data")
default_path = "simulated_quant_risk_dataset.csv"
uploaded = st.sidebar.file_uploader("Upload CSV (optional). If empty, uses the synthetic dataset.", type=["csv"])

# Try to load pre-trained model
model_info = None
if os.path.exists("model.pkl"):
    try:
        with open("model.pkl", "rb") as f:
            model_info = pickle.load(f)
        st.sidebar.success("Loaded pre-trained model.pkl")
    except Exception as e:
        st.sidebar.warning(f"Could not load model.pkl: {e}")

# Load dataset
if uploaded is not None:
    df = pd.read_csv(uploaded)
else:
    try:
        df = pd.read_csv(default_path)
    except Exception:
        st.error("Couldn't find simulated_quant_risk_dataset.csv in current directory. Please upload a CSV.")
        st.stop()

# Column choices
st.sidebar.header("Columns")
all_cols = df.columns.tolist()
target_guess = None
for guess in ["risk_outcome", "target", "label"]:
    if guess in all_cols:
        target_guess = guess
        break
if target_guess is None:
    target_guess = all_cols[-1]

target_col = st.sidebar.selectbox("Target column (binary)", all_cols, index=all_cols.index(target_guess))
feature_cols = st.sidebar.multiselect("Feature columns", [c for c in all_cols if c != target_col], default=[c for c in all_cols if c != target_col])

if target_col not in df.columns:
    st.error("Selected target column not in dataframe.")
    st.stop()
if len(feature_cols) == 0:
    st.error("Please select at least one feature column.")
    st.stop()

X = df[feature_cols].copy()
y = df[target_col].copy()

# Numeric-only for demo simplicity
num_cols = [c for c in feature_cols if np.issubdtype(X[c].dtype, np.number)]
if len(num_cols) < len(feature_cols):
    st.warning("Some non-numeric columns were dropped for this demo. Consider encoding them before training.")
X = X[num_cols]

test_size = st.sidebar.slider("Test size", 0.1, 0.5, 0.25, 0.05)
random_state = st.sidebar.number_input("Random state", value=7, step=1)

# Split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size, stratify=y, random_state=random_state)

# If pre-trained model is compatible with current features, use it
use_pretrained = False
if model_info is not None:
    trained_feats = model_info.get("features", [])
    if set(trained_feats).issubset(set(X.columns)):
        model = model_info["pipeline"]
        use_pretrained = True
        st.info("Using pre-trained model for predictions.")
    else:
        st.warning("Pre-trained model features do not match current dataset; retraining instead.")

if not use_pretrained:
    preprocess = ColumnTransformer([("num", StandardScaler(), num_cols)])
    model = Pipeline([("prep", preprocess), ("clf", GradientBoostingClassifier(random_state=random_state))])
    with st.spinner("Training model..."):
        model.fit(X_train, y_train)

    # Offer to save trained model
    if st.sidebar.button("Save trained model as model.pkl"):
        try:
            with open("model.pkl", "wb") as f:
                pickle.dump({"pipeline": model, "features": num_cols, "target": target_col}, f)
            st.sidebar.success("Saved model.pkl")
        except Exception as e:
            st.sidebar.error(f"Error saving model: {e}")

# Predict
proba = model.predict_proba(X_test)[:, 1]

# Metrics
roc = roc_auc_score(y_test, proba)
pr = average_precision_score(y_test, proba)
brier = brier_score_loss(y_test, proba)

col1, col2, col3 = st.columns(3)
col1.metric("ROC-AUC", f"{roc:.3f}")
col2.metric("PR-AUC", f"{pr:.3f}")
col3.metric("Brier score (↓)", f"{brier:.3f}")

# Plots
st.subheader("Diagnostics")
fig1, ax1 = plt.subplots(figsize=(5,4))
fpr, tpr, _ = roc_curve(y_test, proba)
ax1.plot(fpr, tpr, label="Model")
ax1.plot([0,1],[0,1], "--", label="Random")
ax1.set_title("ROC Curve")
ax1.set_xlabel("FPR")
ax1.set_ylabel("TPR")
ax1.legend()
st.pyplot(fig1)

fig2, ax2 = plt.subplots(figsize=(5,4))
prec, rec, _ = precision_recall_curve(y_test, proba)
ax2.plot(rec, prec, label="Model")
ax2.set_title("Precision–Recall Curve")
ax2.set_xlabel("Recall")
ax2.set_ylabel("Precision")
ax2.legend()
st.pyplot(fig2)

# Permutation importance
st.subheader("Feature Importance (Permutation)")
from sklearn.inspection import permutation_importance
r = permutation_importance(model, X_test, y_test, n_repeats=5, random_state=random_state)
imp = (
    pd.DataFrame({"feature": num_cols, "importance_mean": r.importances_mean, "importance_std": r.importances_std})
    .sort_values("importance_mean", ascending=False)
    .reset_index(drop=True)
)
st.dataframe(imp)

# Thresholding
st.subheader("Thresholding")
threshold = st.slider("Decision threshold", 0.1, 0.9, 0.5, 0.05)
preds = (proba >= threshold).astype(int)

from sklearn.metrics import confusion_matrix, f1_score, accuracy_score
cm = confusion_matrix(y_test, preds)
f1 = f1_score(y_test, preds)
acc = accuracy_score(y_test, preds)
c1, c2 = st.columns(2)
with c1:
    st.write("Confusion Matrix")
    st.write(pd.DataFrame(cm, index=["Actual 0", "Actual 1"], columns=["Pred 0", "Pred 1"]))
with c2:
    st.metric("Accuracy", f"{acc:.3f}")
    st.metric("F1 Score", f"{f1:.3f}")

st.caption("Tip: Place 'model.pkl' and your CSV in the same folder as the app. If features match, the app will use the pre-trained model; otherwise it will train a new one.")
